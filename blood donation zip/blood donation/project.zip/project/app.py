from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__)

# In-memory database for demonstration purposes
donors = []

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/contact')
def contact():
    return render_template('contact.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        donor = {
            'name': request.form['name'],
            'age': request.form['age'],
            'gender': request.form['gender'],
            'blood_type': request.form['blood-type'],
            'city': request.form['city'],
            'phone': request.form['phone']
        }
        donors.append(donor)
        return redirect(url_for('donors'))
    return render_template('register.html')

@app.route('/donors')
def donors():
    return render_template('donors.html', donors=donors)

if __name__ == '__main__':
    app.run(debug=True)
